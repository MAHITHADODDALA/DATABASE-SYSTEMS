

<?php
session_start();
include("dbconnect.php");

$STUDENTNAME = strtoupper( $_POST["STUDENTNAME"]);
$KUID = $_POST["KUID"];


$query = mysql_query("SELECT * FROM STUDENT WHERE STUDENTNAME = '$STUDENTNAME' AND KUID = '$KUID' ");
$check = mysql_fetch_array($query);

if(!empty($STUDENTNAME) && $STUDENTNAME == $check[0] && $KUID == $check[1] )
{
   $_SESSION['STUDENT'] = $STUDENTNAME;
   header("Location:selectdept.php");
}
else
{

	header("Location:loginpage.php");
}
?>
 
