
<?php
session_start();
include'dbconnect.php';

$DEPT=$_POST['DEPARTMENT'];

$_SESSION['DEPARTMENT'] = $DEPT;
header("Location:selectcourse.php");


?>


