

<!DOCTYPE html>
<html>


<head>
<style>
#header {
    background-color:lightblue;
    color:white;
    text-align:center;
    padding:10px;
}

</style>
</head>


<div id="header">
<font color="darkblue"><h1>PLEASE ENTER THE COURSE NUMBER FOR WHICH YOU WANT TUTORING?</h1></font>
</div>

<style> 

#body1 

{       
    background-image: url("http://www.desktopaper.com/wp-content/uploads/popular-ku-jayhawk.jpg");
    background-repeat: no-repeat;
    background-position: center;
    padding: 330px;
    background-color:BLACK;

}
</style>

<style>
p.pos_fixed {
    position:left;
    top: 100px;
    right: 500px;
    color: blue;
}
</style>
<body>
<div id = "body1">

  <p> <form action= "selecttutor.php" method = "post">   </p>
       <p>  <font size="4"><font color="red">COURSENUM<input type ="text" name = "COURSENUM"></font></font> </p>
       <p>  <font color="red"><input type = "SUBMIT" value = "submit"></p></font> <br>
       
    </form>

</div>

</body>

</html>
