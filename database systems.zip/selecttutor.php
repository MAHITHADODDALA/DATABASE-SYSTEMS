<html>

<?php
session_start();
include'dbconnect.php';

$DEPT = $_SESSION['DEPARTMENT'];
$COURSE = $_POST['COURSENUM'];


$query = mysql_query("SELECT * FROM SELECTTUTOR WHERE DEPT_NAME = '$DEPT' AND COURSE_NUM= '$COURSE'");
$num_rows = mysql_num_rows($query);

if ( $num_rows > 0) 
{
?>
<div>
 <p>  <font color="red">AVAILABLE TUTORS FOR THE COURSE YOU SELECTED</p></font> <br>
</div>
<?php
while($row=mysql_fetch_array($query))
{
$_SESSION['TUTOR']=$TUTOR;
  $_SESSION['COURSE']=$COURSE;
  
   echo "TUTOR_ID:".$row["TUTOR_ID"]."<br>"."TUTOR_NAME:".$row["TUTOR_NAME"]."<br>"."DEPT_NAME:".$row["DEPT_NAME"]."<br>"."COURSE_NUM:".$row["COURSE_NUM"]."<br>"."PHONE:".$row["PHONE"]."<br>"."ACCENT:".$row["ACCENT"]."<br>"."<br>";  
    
}
?>
<div>
<p>  <form action= "confirm.php" method = "post">  </p>
       
      <p>  <font color="red">ENTER TUTOR NAME OF YOUR CHOICE FROM THE LISTED TUTORS<input id="tex1" type = "text" name ="TUTOR"></font>  </p>
      <p>  <font color="red"><input id="sub1" type = "submit" value = "submit" onclick="javascript:return validateMyForm();"></p></font> <br>
       
</form>
</div>
<?php
}
 else 
{
    echo"SORRY!TUTORS ARE NOT AVAILABLE FOR THIS COURSE";
}

?>
 
</html>






