MAHITHA DODDALA
KU ID: 2787070

------------------------------------------------------

1)Unzip the project folder and Save it in public_html folder of KU EECS account. 
2)For example,if the folder is saved in my EECS ACCOUNT,I would open the browser and type
 "people.eecs.ku.edu/~mdoddala/dbconnect.php",which connects my database to the web server.
3)Then type "people.eecs.ku.edu/~mdoddala/loginpage.php" which asks for student name and KU ID of the student,
from this page you will be automatically directed to the next pages till you get a "CONFIRMATION" Page.
 