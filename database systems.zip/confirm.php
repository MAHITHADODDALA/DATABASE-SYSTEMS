
<html>
<?php
session_start();
include("dbconnect.php");
?>
<?php

$STUDENTNAME = $_SESSION['STUDENT'];
$DEPT = $_SESSION['DEPARTMENT'];
$COURSE = $_SESSION['COURSE'];
$TUTOR=strtoupper($_POST['TUTOR']);

$query = mysql_query("SELECT * FROM SELECTTUTOR WHERE DEPT_NAME = '$DEPT' AND COURSE_NUM= '$COURSE' AND TUTOR_NAME = '$TUTOR'");
$num_rows = mysql_num_rows($query);

if ( $num_rows > 0) 
{
?>
<div>
<p>   <font size="6"><font color="red">CONFIRMATION PAGE</font></font></p>
<p>   <font size="4"><font color="blue">A TUTOR HAS BEEN SUCCESSFULLY ASSIGNED TO YOU!!!</font></font></p>


</div>
<?php
	echo "STUDENT_NAME: " . $STUDENTNAME ."<br>". "  DEPARTMENT_NAME: " . $DEPT."<br>". "  COURSE_NUMBER: " . $COURSE."<br>". "TUTOR_NAME: ". $TUTOR . "<br>";
}

else
{
	echo 'PLEASE SELECT THE TUTOR ONLY FROM THE LISTED TUTORS!!!';
}

?>
</html>