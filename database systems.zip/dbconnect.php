


<?php
// Connecting, selecting database
$conn = mysql_connect('mysql.eecs.ku.edu', 'mdoddala', 'Nf99guKH')
or die('Could not connect: ' . mysql_error());

mysql_select_db('mdoddala') or die('Could not select database');


?>




