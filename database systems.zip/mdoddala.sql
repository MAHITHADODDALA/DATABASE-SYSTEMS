-- phpMyAdmin SQL Dump
-- version 3.4.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 20, 2014 at 02:08 AM
-- Server version: 5.1.73
-- PHP Version: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `mdoddala`
--

-- --------------------------------------------------------

--
-- Table structure for table `COURSE`
--

CREATE TABLE IF NOT EXISTS `COURSE` (
  `COURSE_NUM` bigint(250) NOT NULL,
  `COURSE_ID` bigint(250) NOT NULL,
  PRIMARY KEY (`COURSE_ID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `COURSE`
--

INSERT INTO `COURSE` (`COURSE_NUM`, `COURSE_ID`) VALUES
(101, 1231),
(104, 1234),
(115, 1235),
(116, 1236),
(114, 1345),
(131, 1453),
(115, 1466),
(105, 2345),
(130, 2347),
(102, 3452);

-- --------------------------------------------------------

--
-- Table structure for table `COURSE_LIST`
--

CREATE TABLE IF NOT EXISTS `COURSE_LIST` (
  `DEPT_NAME` varchar(255) NOT NULL,
  `COURSE_NUM` bigint(250) NOT NULL,
  PRIMARY KEY (`DEPT_NAME`,`COURSE_NUM`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `COURSE_LIST`
--

INSERT INTO `COURSE_LIST` (`DEPT_NAME`, `COURSE_NUM`) VALUES
('BIOLOGY', 101),
('BIOLOGY', 102),
('CHEMISTRY', 130),
('CHEMISTRY', 131),
('MATHEMATICS', 104),
('MATHEMATICS', 105),
('MATHEMATICS', 115),
('MATHEMATICS', 116),
('PHYSICS', 114),
('PHYSICS', 115);

-- --------------------------------------------------------

--
-- Table structure for table `DEPARTMENT`
--

CREATE TABLE IF NOT EXISTS `DEPARTMENT` (
  `DEPT_NAME` varchar(255) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  `DEPT_ID` bigint(250) NOT NULL,
  PRIMARY KEY (`DEPT_NAME`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `DEPARTMENT`
--

INSERT INTO `DEPARTMENT` (`DEPT_NAME`, `DEPT_ID`) VALUES
('BIOLOGY\r\n', 1003),
('CHEMISTRY', 1002),
('MATHEMATICS', 1000),
('PHYSICS', 1001);

-- --------------------------------------------------------

--
-- Stand-in structure for view `SELECTTUTOR`
--
CREATE TABLE IF NOT EXISTS `SELECTTUTOR` (
`TUTOR_ID` bigint(255)
,`TUTOR_NAME` varchar(255)
,`DEPT_NAME` varchar(255)
,`COURSE_NUM` bigint(250)
,`PHONE` bigint(250)
,`ACCENT` varchar(250)
);
-- --------------------------------------------------------

--
-- Table structure for table `STUDENT`
--

CREATE TABLE IF NOT EXISTS `STUDENT` (
  `STUDENTNAME` varchar(255) CHARACTER SET utf8 NOT NULL,
  `KUID` bigint(250) NOT NULL,
  PRIMARY KEY (`KUID`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `STUDENT`
--

INSERT INTO `STUDENT` (`STUDENTNAME`, `KUID`) VALUES
('JORDAN', 2134528),
('MILLER', 2674532),
('SRIMAN', 2769403),
('ALEX', 2781345),
('KATIE', 2787070);

-- --------------------------------------------------------

--
-- Table structure for table `TUTOR`
--

CREATE TABLE IF NOT EXISTS `TUTOR` (
  `TUTOR_NAME` varchar(255) NOT NULL,
  `DEPT_NAME` varchar(255) NOT NULL,
  `COURSE_NUM` bigint(250) NOT NULL,
  PRIMARY KEY (`TUTOR_NAME`,`DEPT_NAME`,`COURSE_NUM`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `TUTOR`
--

INSERT INTO `TUTOR` (`TUTOR_NAME`, `DEPT_NAME`, `COURSE_NUM`) VALUES
('ASHER', 'BIOLOGY', 102),
('ASHER', 'PHYSICS', 114),
('ASHER', 'PHYSICS', 115),
('JOSEPH', 'BIOLOGY', 101),
('JOSEPH', 'CHEMISTRY', 130),
('JOSEPH', 'CHEMISTRY', 131),
('JOSEPH', 'MATHEMATICS', 104),
('JOSEPH', 'MATHEMATICS', 115),
('KARTHIK', 'BIOLOGY', 102),
('KARTHIK', 'MATHEMATICS', 115),
('KARTHIK', 'MATHEMATICS', 116),
('KARTHIK', 'PHYSICS', 114),
('KARTHIK', 'PHYSICS', 115),
('MARINDA', 'BIOLOGY', 101),
('MARINDA', 'BIOLOGY', 102),
('MARINDA', 'MATHEMATICS', 116),
('PARKER', 'MATHEMATICS', 105),
('PARKER', 'PHYSICS', 114),
('SIDDHARTH', 'BIOLOGY', 101),
('SIDDHARTH', 'CHEMISTRY', 130),
('SIDDHARTH', 'CHEMISTRY', 131),
('SIDDHARTH', 'MATHEMATICS', 104),
('SIDDHARTH', 'MATHEMATICS', 105),
('WILL', 'BIOLOGY', 102),
('WILL', 'CHEMISTRY', 130),
('WILL', 'MATHEMATICS', 104);

-- --------------------------------------------------------

--
-- Table structure for table `TUTOR_INFO`
--

CREATE TABLE IF NOT EXISTS `TUTOR_INFO` (
  `TUTOR_NAME` varchar(255) NOT NULL,
  `TUTOR_ID` bigint(255) NOT NULL,
  `PHONE` bigint(250) NOT NULL,
  `ACCENT` varchar(250) NOT NULL,
  PRIMARY KEY (`TUTOR_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `TUTOR_INFO`
--

INSERT INTO `TUTOR_INFO` (`TUTOR_NAME`, `TUTOR_ID`, `PHONE`, `ACCENT`) VALUES
('JOSEPH', 1, 7854323421, 'AMERICAN'),
('MARINDA', 2, 7854328756, 'BRITISH'),
('ASHER', 3, 7854325677, 'AMERICAN'),
('PARKER', 4, 7856432189, 'BRITISH'),
('WILL', 5, 7856435643, 'BRITISH '),
('KARTHIK', 6, 7855050653, 'INDIAN'),
('SIDDARTH', 7, 7854563247, 'INDIAN');

-- --------------------------------------------------------

--
-- Structure for view `SELECTTUTOR`
--
DROP TABLE IF EXISTS `SELECTTUTOR`;

CREATE ALGORITHM=UNDEFINED DEFINER=`mdoddala`@`%` SQL SECURITY DEFINER VIEW `SELECTTUTOR` AS select `I`.`TUTOR_ID` AS `TUTOR_ID`,`T`.`TUTOR_NAME` AS `TUTOR_NAME`,`T`.`DEPT_NAME` AS `DEPT_NAME`,`T`.`COURSE_NUM` AS `COURSE_NUM`,`I`.`PHONE` AS `PHONE`,`I`.`ACCENT` AS `ACCENT` from (`TUTOR` `T` join `TUTOR_INFO` `I`) where (`T`.`TUTOR_NAME` = `I`.`TUTOR_NAME`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
